# Find-Patterns-in-Prime-Numbers (Windows version)
This program help to find patterns in Prime Nubmers with Python, Turtle and Tkinter. The speed in the animations is increased.

In the dist folder you can find the executable file for windows.
